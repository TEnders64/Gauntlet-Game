// your code here

// warmup
// $('img').click(function(){
//     alert($(this).attr('alt'));
// })

// medium heat
$('button').click(function(){
    $('div:last').append('<img src="images/newtech.png" alt="new tech">')
    // could also give an ID to the div in HTML and select it that way
})

// inferno
$('body').on('click', 'img', function(){
    alert($(this).attr('alt'));
})
